<?php 
	ini_set('error_reporting', 1);
	require './includes/header.php';
	require_once '../../mysqli_config.php';  //$dbc is the connection string set upon successful connection
	function shortTitle ($title){
		$title = substr($title, 0, -4);
		$title = str_replace('_', ' ', $title);
		$title = ucwords($title);
		return $title;
	}
	$query = "SELECT * FROM JJ_images";
	$result = mysqli_query($dbc, $query);
	//Fetch all rows of result as an associative array
	if($result)
		mysqli_fetch_all($result, MYSQLI_ASSOC);
	else { 
		echo mysqli_error($result);  //Change to a generic message error before deployment
		mysqli_close($dbc);
		exit; 
		//or for deployment
		//echo "We are unable to process your request at  this  time. Please try again later.";
		include 'includes/footer.php'; 
		exit;
	   } 
	?>
  <main>
	<h2>Images of Japan</h2>
	<h3>Each of our lovely images may be purchased for you to enjoy in your home or to give as a gift</h3>
	<h4>Please click the View Details button to make a purchase</h4>      
    <table>
        <tr>
            <th>Title</th>
			<th>Image</th>
			<th></th>
        </tr>
        <?php foreach ($result as $row) { ?>
		<tr>
			<td><?php echo shortTitle($row['filename']); ?></td>
			<td><img src = "images/thumbs/<?php echo $row['filename'];?>" alt="Japan Image">	
			<td><a href="<?php echo rtrim('https://'. $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']),'/\\');?>
			/product_details.php?ImageID=<?php echo $row['image_id'];?>">View Details</a>
        </tr>
    <?php } //endforeach loop ?>
    </table>
  </main>
<?php include 'includes/footer.php'; ?>