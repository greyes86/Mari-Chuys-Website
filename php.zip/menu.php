	<?php 
	$currentPage = basename($_SERVER['SCRIPT_FILENAME']); ?>
	<ul id="nav">
        <li><a href="index.php" <?php if ($currentPage == 'index.php') {echo 'id="here"'; } ?>>Home</a></li>
        <li><a href="#" <?php if ($currentPage == 'blog.php') {echo 'id="here"'; } ?>>Blog</a></li>
        <li><a href="#" <?php if ($currentPage == 'gallery.php') {echo 'id="here"'; } ?>>Gallery</a></li>
		<li><a href="cart.php" <?php if ($currentPage == 'cart.php') {echo 'id="here"'; } ?>>Cart</a></li>
		<li><a href="cart_view.php" <?php if ($currentPage == 'cart_view.php') {echo 'id="here"'; } ?>>Cart_View</a></li>
		<li><a href="product_list.php" <?php if ($currentPage == 'product_list.php') {echo 'id="here"'; } ?>>Purchase Prints</a></li>
		<?php
		if (isset($_SESSION['email'])){
			echo '<li><a href="upload_image.php"'.'>Upload images</a></li>';
			echo '<li><a href="images.php"'.'>View images</a></li>';
			echo '<li><a href="logged_out.php"'.'>Logout</a></li>';
		}
		else{
			echo '<li><a href="register.php"';
			if ($currentPage == 'register.php') {
				echo'id="here"';
				}
			echo '>Register</a></li>';
			
			echo '<li><a href="login.php"';
			if ($currentPage == 'login.php') {
				echo 'id="here"'; 
				}
			echo '>Login</a></li>';
		}
		
		?>
    </ul>